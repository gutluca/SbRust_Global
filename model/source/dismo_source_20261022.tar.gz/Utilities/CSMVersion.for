!=======================================================================
!  MODULE CSMVersion
!  07/05/2018 CV  Written
!=======================================================================

      MODULE CSMVersion
!     Contains defintion of version and branch which will be
!     used throughout the model.

!=======================================================================

!     Global CSM Version Number
      TYPE VersionType
        INTEGER :: Major = 4
        INTEGER :: Minor = 8
        INTEGER :: Model = 6
        INTEGER :: Build = 4
      END TYPE VersionType
      TYPE (VersionType) Version
      CHARACTER(len=*), PARAMETER :: VBranch = '-dismo-integration'

!     Version history:
!       4.8.6.4   FO 2026-10-02 v4.8.6.4 commit hash: 3a8e932
!       4.8.6.3   FO 2026-09-30 v4.8.6.3 commit hash: 4fbcfa7
!       4.8.6.2   FO 2026-09-22 v4.8.6.2 commit hash: 7cebd47
!       4.8.6.1   FO 2026-09-14 v4.8.6.1 commit hash: 9742142
!       4.8.6.0   FO 2026-07-01 v4.8.6 Release 2026
!       4.8.5.0   FO 2024-12-19 v4.8.5 Release 2024
!       4.8.2.0   FO 2023-09-02 v4.8.2 Release 2023
!       4.8.1.0   FO 2022-10-28 v4.8.1 Interim release 2022
!       4.8.0.1  chp 2020-07-21 v4.8 (=v4.7.5.14)
!       4.7.5.0  chp 2018-12-18 Pre-release version
!       4.7.2.0  chp 2018-05-07 v4.7.2 Release 2018 Workshop
!       4.7.1.0  chp 2017-10-27 v4.7.1 Release
!       4.7.0.0  chp 2017-08-09 v4.7.0 Release
!       4.6.5.1  chp 2017-05-10 v4.6.5 Release 2017 Workshop  
!       4.6.0.1  chp 2011-06-28 v4.6.0 Release
!       4.5.1.0  chp 2010-10-10 v4.5.1 Release
!       4.0.2.0  chp 2005-08-11 v4.0.2 Release
!       4.0.1.0  chp 2004-01-28 v4.0.1 Release 
!=======================================================================
      END MODULE CSMVersion

